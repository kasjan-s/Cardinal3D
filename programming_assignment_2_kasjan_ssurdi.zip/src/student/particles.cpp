
#include "../scene/particles.h"


#include "../scene/particles.h"

bool Particle::update(const PT::BVH<PT::Object>& scene, float dt, float radius) {

    return false;
}
